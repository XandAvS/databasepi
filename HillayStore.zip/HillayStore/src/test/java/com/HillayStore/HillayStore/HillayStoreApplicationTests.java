package com.HillayStore.HillayStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HillayStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
